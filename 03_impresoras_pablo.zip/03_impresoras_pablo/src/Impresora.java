public class Impresora implements Runnable{
    //Definicion de variables
    private final String nombre;
    private final int totalPaginas;

    //Constructor
    public Impresora(String nombre, int totalPaginas){
        this.nombre = nombre;
        this.totalPaginas = totalPaginas;
    }

    @Override
    public void run() {
        //Recorre las paginas desde la 1 hasta el total
        for (int paginaActual = 1; paginaActual <= totalPaginas; paginaActual++){
            System.out.println(nombre + ": imprimiendo página " + paginaActual + " de " + totalPaginas);
            try{
                //Simula el tiempo que tarda en imprimir una pagina
                Thread.sleep(1000);
            }catch (InterruptedException e){
                //Se restablece la interrupcion y se termina la tarea
                Thread.currentThread().interrupt();
                System.out.println(nombre + ": impresión interrumpida");
                return;
            }
        }
        //Mensaje de finalizacion
        System.out.println(nombre + ": impresión finalizada");
    }
}
