public class Main {
    public static void main(String[] args) {
        //Creo las tres tareas de impresion
        Impresora impresoraA = new Impresora("Impresora A", 3);
        Impresora impresoraB = new Impresora("Impresora B", 5);
        Impresora impresoraC = new Impresora("Impresora C", 4);

        //Asocio cada tarea a un hilo
        Thread hiloA = new Thread(impresoraA);
        Thread hiloB = new Thread(impresoraB);
        Thread hiloC = new Thread(impresoraC);

        //Lanzo los hilos
        hiloA.start();
        hiloB.start();
        hiloC.start();
    }
}
