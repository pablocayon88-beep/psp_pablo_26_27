import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        try {
            //Creo el proceso: ping con 4 paquetes a localhost (en windows cambiar -c por -n) y lo lanzo
            ProcessBuilder constructorProceso = new ProcessBuilder("ping", "-c", "4", "localhost");
            Process procesoPing = constructorProceso.start();

            //Compruebo si esta vivo nada mas lanzarlo
            System.out.println("Esta vivo al principio: " + procesoPing.isAlive());

            //Saco el PID
            System.out.println("PID: " + procesoPing.pid());

            //Saco el comando
            if (procesoPing.info().command().isPresent()) {
                System.out.println("Comando: " + procesoPing.info().command().get());
            }
            else {
                System.out.println("Comando: desconocido");
            }

            //Saco los argumentos
            if (procesoPing.info().arguments().isPresent()) {
                String[] argumentos = procesoPing.info().arguments().get();
                System.out.print("Argumentos:");
                for (String argumento : argumentos) {
                    System.out.print(" " + argumento);
                }
                System.out.println();
            }
            else {
                System.out.println("Argumentos: desconocidos");
            }

            //Saco el usuario
            if (procesoPing.info().user().isPresent()) {
                System.out.println("Usuario: " + procesoPing.info().user().get());
            }
            else {
                System.out.println("Usuario: desconocido");
            }

            //Leo lo que el proceso va escribiendo por pantalla
            Scanner lectorSalida = new Scanner(procesoPing.getInputStream());

            while (lectorSalida.hasNextLine()) {
                String lineaSalida = lectorSalida.nextLine();
                System.out.println(lineaSalida);
            }


            //Espero a que el proceso termine y guardo su codigo de salida
            int codigoSalida = procesoPing.waitFor();

            //Muestro el resultado final
            System.out.println("Resultado final: " + codigoSalida);

            //Compruebo si sigue vivo una vez terminado
            System.out.println("Esta vivo al final: " + procesoPing.isAlive());

        }

        //Capturo las excepciones posibles al lanzar el proceso o al esperar a que termine
        catch (IOException e) {
            //Falla si el comando ping no existe o no se puede leer su salida
            System.out.println("Error al lanzar o leer el proceso: " + e.getMessage());
        }
        catch (InterruptedException e) {
            //Se restablece la interrupcion del hilo
            Thread.currentThread().interrupt();
            System.out.println("Se interrumpio la espera del proceso");
        }


    }
}