public class Main {
    public static void main(String[] args) {
        //Creo el contador compartido q empieza en 0
        Contador contador = new Contador(0);

        //Creo las 2 tareas q hacen las mismas vueltas para que acaben a la vez
        Sumador sumador = new Sumador(contador, 10);
        Restador restador = new Restador(contador, 10);

        //cada tarea a un hilo con nombre
        Thread hiloSumador = new Thread(sumador, "Sumador");
        Thread hiloRestador = new Thread(restador, "Restador");

        //lanzo el hilo del sumador y el del restador
        hiloRestador.start();
        hiloSumador.start();

        //Espero a que acaben los hilos para poder mostrar el valor final
        try {
            hiloSumador.join();
            hiloRestador.join();
        } catch (InterruptedException e) {
            //Se restablece la interrupcion
            Thread.currentThread().interrupt();
            System.out.println("Se interrumpio la espera de los hilos");
        }

        //Si ha ido bien tiene que quedar en el valor inicial
        System.out.println("Valor final: " + contador.getValor());
    }
    
}
