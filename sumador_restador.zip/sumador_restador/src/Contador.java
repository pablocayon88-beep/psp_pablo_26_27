public class Contador {

    private int valor;
    private boolean turnoSumador;

    public Contador(int valorInicial) {
        this.valor = valorInicial;
        this.turnoSumador = true;
    }

    //Suma 1 al contador solo si es el turno del sumador
    public synchronized void sumar() {
        while (!turnoSumador) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
        valor++;
        System.out.println(Thread.currentThread().getName() + " suma : " + valor);

        //paso el turno al restador y despierto a los hilos que esperan
        turnoSumador = false;
        notifyAll();
    }

    //resta 1 al contador solo si es el turno del restador
    public synchronized void restar() {
        while (turnoSumador) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
        valor--;
        System.out.println(Thread.currentThread().getName() + " resta : " + valor);

        //paso el turno al sumador y despierto a los hilos que esperan
        turnoSumador = true;
        notifyAll();
    }

    //Devuelve el valor actual del contador
    public synchronized int getValor() {
        return valor;
    }

}
