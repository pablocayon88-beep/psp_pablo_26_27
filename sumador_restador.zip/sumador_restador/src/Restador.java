public class Restador implements Runnable {

    private final Contador contador;
    private final int vecesARestar;

    public Restador(Contador contador, int vecesARestar) {
        this.contador = contador;
        this.vecesARestar = vecesARestar;
    }

    @Override
    public void run() {
        for (int i = 0; i < vecesARestar; i++) {
            contador.restar();
        }
    }

}
