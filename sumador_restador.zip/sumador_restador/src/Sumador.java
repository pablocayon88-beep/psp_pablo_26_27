public class Sumador implements Runnable {

    private final Contador contador;
    private final int vecesASumar;

    public Sumador(Contador contador, int vecesASumar) {
        this.contador = contador;
        this.vecesASumar = vecesASumar;
    }

    @Override
    public void run() {
        for (int i = 0; i < vecesASumar; i++) {
            contador.sumar();
        }
    }

}
